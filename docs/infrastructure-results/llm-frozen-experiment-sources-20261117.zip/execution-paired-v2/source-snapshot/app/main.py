import asyncio
from dataclasses import replace
from datetime import UTC, datetime
from functools import lru_cache
from pathlib import Path
from time import perf_counter
from typing import Annotated, Literal

from fastapi import Depends, FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from mangum import Mangum
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest
from starlette.middleware.trustedhost import TrustedHostMiddleware

from app.analyzers import HybridAnalyzer, OpenAIAnalyzer, RuleBasedAnalyzer
from app.analyzers.base import Analyzer
from app.behavior_context_api import behavior_context_router
from app.config import get_settings
from app.dashboard_api import router as dashboard_router
from app.dashboard_jobs_api import router as dashboard_jobs_router
from app.middleware import RequestBodyLimitMiddleware, RequestContextMiddleware
from app.models import (
    AnalysisResult,
    AssuranceSummary,
    BatchAnalysisRequest,
    BatchAnalysisResult,
    ControlRecord,
    ControlStatus,
    CorrelationPolicy,
    CorrelationRequest,
    CorrelationResult,
    DetectionPipelineResult,
    DetectionQualityReport,
    EvaluationRequest,
    EvaluationSummary,
    EventScenarioEvaluation,
    IncidentCase,
    IncidentCaseCreateRequest,
    IncidentCaseCreateResult,
    IncidentCaseMetrics,
    IncidentCaseStatus,
    IncidentCaseUpdateRequest,
    IncidentQualityReport,
    IntegrationDeliveryStatus,
    IntegrationDeliveryUpdateRequest,
    IntegrationOutboxMetrics,
    IntegrationOutboxRecord,
    IntegrationReconcileResult,
    MetricsSummary,
    NormalizedSecurityEvent,
    PolicyDecision,
    PublicReplayDataset,
    PublicReplayResult,
    PublicReplaySuiteResult,
    ResponsePreviewRequest,
    ReviewStatus,
    ReviewUpdateRequest,
    RiskLevel,
    ScenarioSummary,
    SecurityEvent,
    SigmaRuleSummary,
    SimulationRequest,
)
from app.response_api import response_router
from app.scenarios import SCENARIOS, generate_events, get_scenario
from app.security import Principal, Role, require_roles
from app.services.assurance import get_assurance_registry
from app.services.audit import create_audit_store
from app.services.behavior_context import BehaviorContextService
from app.services.behavior_context_store import BehaviorContextStore
from app.services.cases import (
    ALLOWED_TRANSITIONS,
    CaseConflictError,
    CaseNotFoundError,
    IncidentCaseService,
    InvalidCaseTransitionError,
    create_case_store,
)
from app.services.continuous_signals import ContinuousSignalService
from app.services.correlation import get_correlation_engine
from app.services.detection_benchmark import BenchmarkUnavailable, get_detection_benchmark
from app.services.detection_quality import get_detection_quality_service
from app.services.evaluation import run_evaluation
from app.services.execution_analysis_evidence import collect_session_execution_evidence
from app.services.incident_quality import get_incident_quality_service
from app.services.integration_outbox import (
    IntegrationOutboxService,
    OutboxConflictError,
    OutboxNotDueError,
    OutboxNotFoundError,
    OutboxTerminalStateError,
    create_integration_outbox_store,
)
from app.services.ocsf import get_ocsf_normalizer
from app.services.policy import enforce_assessment_safety, response_preview
from app.services.public_detection import PublicSession, evaluate_public_session
from app.services.public_replay import get_public_replay_service
from app.services.response_actions import ResponseService
from app.services.scenario_evaluator import evaluate_scenarios
from app.services.session_analysis_evidence import VerifiedSessionContext, collect_session_evidence
from app.services.sigma import get_sigma_engine
from app.services.signal_inbox import SignalInbox
from app.services.trusted_signals import SignalVerifier
from app.services.zero_trust import POLICY_PATH, ZeroTrustOperations
from app.zero_trust_api import install_zero_trust_error_handlers, zero_trust_router
from app.zero_trust_models import SignedSessionSignal

settings = get_settings()
static_dir = Path(__file__).parent / "static"
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="합성·공개 이벤트 기반 제로 트러스트 탐지 품질 및 대응 시뮬레이션 API",
    docs_url=None if settings.app_environment == "production" else "/docs",
    redoc_url=None if settings.app_environment == "production" else "/redoc",
    openapi_url=None if settings.app_environment == "production" else "/openapi.json",
)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=settings.allowed_host_list)
app.add_middleware(RequestBodyLimitMiddleware, max_bytes=settings.api_max_body_bytes)
app.add_middleware(RequestContextMiddleware)
app.mount("/static", StaticFiles(directory=static_dir), name="static")
app.include_router(dashboard_router)
app.include_router(dashboard_jobs_router)
audit_store = create_audit_store(settings)
case_store = create_case_store(settings)
integration_outbox_store = create_integration_outbox_store(settings)
integration_outbox_service = IntegrationOutboxService(integration_outbox_store)
case_service = IncidentCaseService(case_store, integration_outbox_service)
assurance_registry = get_assurance_registry()
ocsf_normalizer = get_ocsf_normalizer()
sigma_engine = get_sigma_engine()
correlation_engine = get_correlation_engine()
public_replay_service = get_public_replay_service()
detection_quality_service = get_detection_quality_service()
incident_quality_service = get_incident_quality_service()
analysis_capacity = asyncio.Semaphore(settings.analysis_max_concurrency)
zero_trust_operations = (
    ZeroTrustOperations(settings.zero_trust_db_path,
                        policy_path=settings.zero_trust_policy_path or POLICY_PATH,
                        signal_verifier=SignalVerifier(settings.trusted_signal_sources_path))
    if settings.app_environment != "production" else None
)
continuous_signal_service = (
    ContinuousSignalService(zero_trust_operations, SignalInbox(
        settings.zero_trust_db_path,
        max_pending=settings.signal_inbox_max_pending,
        max_records=settings.signal_inbox_max_records,
        max_attempts=settings.signal_inbox_max_attempts,
        lease_seconds=settings.signal_inbox_lease_seconds,
        retry_seconds=settings.signal_inbox_retry_seconds,
    )) if zero_trust_operations else None
)
app.include_router(zero_trust_router(zero_trust_operations, continuous_signal_service))
install_zero_trust_error_handlers(app)
behavior_context_service = (
    BehaviorContextService(BehaviorContextStore(
        settings.behavior_context_db_path or settings.zero_trust_db_path.with_name(
            settings.zero_trust_db_path.stem + "-behavior-context.sqlite3",
        ),
    ), zero_trust_operations)
    if zero_trust_operations else None
)
app.include_router(behavior_context_router(behavior_context_service))
response_service = (
    ResponseService(behavior_context_service.store, zero_trust_operations)
    if behavior_context_service else None
)
app.include_router(response_router(response_service))

ViewerPrincipal = Annotated[Principal, Depends(require_roles(Role.VIEWER))]
AnalystPrincipal = Annotated[Principal, Depends(require_roles(Role.ANALYST))]
ResponderPrincipal = Annotated[Principal, Depends(require_roles(Role.RESPONDER))]
AdminPrincipal = Annotated[Principal, Depends(require_roles(Role.ADMIN))]


class AnalysisCapacityExceeded(RuntimeError):
    pass


@lru_cache
def get_analyzer() -> Analyzer:
    current = get_settings()
    return build_analyzer(current.analyzer_mode)


def build_analyzer(mode: str) -> Analyzer:
    if mode == "openai":
        return OpenAIAnalyzer(get_settings())
    if mode == "hybrid":
        return HybridAnalyzer(get_settings())
    return RuleBasedAnalyzer()


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "version": settings.app_version,
        "analyzer_mode": settings.analyzer_mode,
        "audit_backend": settings.audit_backend,
        "case_backend": case_store.integrity()["backend"],
        "integration_outbox_backend": integration_outbox_store.integrity()["backend"],
        "auth_mode": settings.auth_mode,
        "environment": settings.app_environment,
    }


@app.get("/health/live")
def liveness() -> dict:
    return {"status": "ok"}


@app.get("/health/ready")
def readiness() -> Response:
    zero_trust_integrity = (
        zero_trust_operations.integrity() if zero_trust_operations else {"ok": True, "enabled": False}
    )
    inbox_integrity = (
        continuous_signal_service.inbox.integrity()
        if continuous_signal_service else {"ok": True, "enabled": False}
    )
    context_integrity = (behavior_context_service.readiness() if behavior_context_service
                         else {"ok": True, "enabled": False})
    integrity = audit_store.integrity()
    case_integrity = case_store.integrity()
    outbox_integrity = integration_outbox_store.integrity()
    assurance = assurance_registry.summary()
    quality = (
        detection_quality_service.evaluate("readiness")
        if public_replay_service.valid and sigma_engine.valid
        else None
    )
    incident_quality = (
        incident_quality_service.evaluate("readiness")
        if public_replay_service.valid and sigma_engine.valid
        else None
    )
    ready = (
        integrity["ok"]
        and zero_trust_integrity["ok"]
        and inbox_integrity["ok"]
        and context_integrity["ok"]
        and case_integrity["ok"]
        and outbox_integrity["ok"]
        and assurance.valid
        and sigma_engine.valid
        and public_replay_service.valid
        and quality is not None
        and quality.gate_passed
        and incident_quality is not None
        and incident_quality.gate_passed
    )
    payload = {
        "status": "ready" if ready else "degraded",
        "signal_inbox": inbox_integrity,
        "behavior_context": context_integrity,
        "audit": integrity,
        "case_management": {
            **case_integrity,
            "valid": case_integrity["ok"],
            "lifecycle": [status.value for status in IncidentCaseStatus],
            "response_mode": "simulation",
            "allowed_transition_count": sum(len(values) for values in ALLOWED_TRANSITIONS.values()),
        },
        "integration_outbox": {
            **outbox_integrity,
            "valid": outbox_integrity["ok"],
            "format": "CloudEvents 1.0",
            "data_schema": "OCSF 1.9.0 Incident Finding",
            "external_delivery_enabled": False,
        },
        "zero_trust_operations": zero_trust_integrity,
        "assurance": {
            "valid": assurance.valid,
            "registry_version": assurance.registry_version,
            "registry_digest_sha256": assurance.registry_digest_sha256,
            "total_controls": assurance.total_controls,
            "overdue_control_count": len(assurance.overdue_control_ids),
        },
        "normalization": {
            "valid": True,
            "schema": "OCSF",
            "schema_version": ocsf_normalizer.schema_version,
            "transformer_version": ocsf_normalizer.transformer_version,
            "mapping_digest_sha256": ocsf_normalizer.mapping_digest_sha256,
        },
        "detection": {
            "valid": sigma_engine.valid,
            "specification": "Sigma",
            "specification_version": "2.1.0",
            "loaded_rule_count": len(sigma_engine.summaries()),
            "approved_rule_count": len(sigma_engine.approved_rules),
            "ruleset_digest_sha256": sigma_engine.ruleset_digest_sha256,
            "validation_issue_count": len(sigma_engine.validation_issues),
        },
        "correlation": {
            "valid": True,
            "version": correlation_engine.version,
            "output_class": "OCSF Incident Finding",
            "output_class_uid": 2005,
            "windows_minutes": [5, 30, 1440],
            "entity_graph_enabled": True,
        },
        "public_replay": {
            "valid": public_replay_service.valid,
            "version": public_replay_service.version,
            "dataset_count": len(public_replay_service.datasets()),
            "manifest_digest_sha256": public_replay_service.manifest_digest_sha256,
            "validation_issue_count": len(public_replay_service.validation_issues),
        },
        "detection_quality": {
            "valid": quality is not None and quality.gate_passed,
            "version": detection_quality_service.version,
            "precision": quality.precision if quality else None,
            "recall": quality.recall if quality else None,
            "f1": quality.f1 if quality else None,
            "false_positive_rate": quality.false_positive_rate if quality else None,
            "parse_success_rate": quality.parse_success_rate if quality else None,
            "mapping_completeness": quality.mapping_completeness if quality else None,
            "rule_coverage_rate": quality.rule_coverage_rate if quality else None,
            "evaluation_fingerprint_sha256": (
                quality.evaluation_fingerprint_sha256 if quality else None
            ),
        },
        "incident_quality": {
            "valid": incident_quality is not None and incident_quality.gate_passed,
            "version": incident_quality_service.version,
            "positive_dataset_support": (
                incident_quality.positive_dataset_support if incident_quality else None
            ),
            "negative_dataset_support": (
                incident_quality.negative_dataset_support if incident_quality else None
            ),
            "precision": incident_quality.precision if incident_quality else None,
            "recall": incident_quality.recall if incident_quality else None,
            "f1": incident_quality.f1 if incident_quality else None,
            "false_positive_rate": (
                incident_quality.false_positive_rate if incident_quality else None
            ),
            "window_accuracy": (
                incident_quality.window_accuracy if incident_quality else None
            ),
            "graph_structure_accuracy": (
                incident_quality.graph_structure_accuracy if incident_quality else None
            ),
            "deduplication_accuracy": (
                incident_quality.deduplication_accuracy if incident_quality else None
            ),
            "evaluation_fingerprint_sha256": (
                incident_quality.evaluation_fingerprint_sha256
                if incident_quality
                else None
            ),
        },
    }
    return JSONResponse(payload, status_code=200 if ready else 503)


@app.get("/", include_in_schema=False)
def dashboard() -> FileResponse:
    return FileResponse(static_dir / "index.html")


@app.get("/scenarios", response_model=list[ScenarioSummary])
def scenarios(_: ViewerPrincipal) -> list[ScenarioSummary]:
    return SCENARIOS


@app.get("/scenarios/{scenario_id}", response_model=ScenarioSummary)
def scenario(scenario_id: str, _: ViewerPrincipal) -> ScenarioSummary:
    try:
        return get_scenario(scenario_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=f"Unknown scenario: {exc.args[0]}") from exc


@app.post("/events/simulate", response_model=list[SecurityEvent])
def simulate(request: SimulationRequest, _: AnalystPrincipal) -> list[SecurityEvent]:
    try:
        return generate_events(request.scenario_id, request.count)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=f"Unknown scenario: {exc.args[0]}") from exc


@app.post("/events/normalize", response_model=NormalizedSecurityEvent)
def normalize_event(event: SecurityEvent, _: AnalystPrincipal) -> NormalizedSecurityEvent:
    return ocsf_normalizer.normalize(event)


@app.post("/detections/evaluate", response_model=DetectionPipelineResult)
def evaluate_detections(event: SecurityEvent, _: AnalystPrincipal) -> DetectionPipelineResult:
    normalized = ocsf_normalizer.normalize(event)
    return DetectionPipelineResult(
        normalized=normalized,
        detection=sigma_engine.evaluate(normalized),
    )


@app.get("/detections/rules", response_model=list[SigmaRuleSummary])
def detection_rules(_: ViewerPrincipal) -> list[SigmaRuleSummary]:
    return sigma_engine.summaries()


@app.post("/detections/public/evaluate")
def evaluate_public_behavior(session: PublicSession, _: AnalystPrincipal) -> dict:
    """Return reference detections; public observations cannot authorize access changes."""
    return evaluate_public_session(session)


@app.post("/incidents/correlate", response_model=CorrelationResult)
def correlate_incidents(
    request: CorrelationRequest,
    principal: AnalystPrincipal,
) -> CorrelationResult:
    return _correlate(request.events, request.policy, principal.tenant_id)


def _correlate(
    events: list[SecurityEvent],
    policy: CorrelationPolicy,
    tenant_id: str,
) -> CorrelationResult:
    pipelines = []
    for event in events:
        normalized = ocsf_normalizer.normalize(event)
        pipelines.append(
            DetectionPipelineResult(
                normalized=normalized,
                detection=sigma_engine.evaluate(normalized),
            )
        )
    return correlation_engine.correlate(pipelines, tenant_id, policy)


@app.post("/cases/from-events", response_model=IncidentCaseCreateResult)
async def create_cases_from_events(
    request: IncidentCaseCreateRequest,
    principal: AnalystPrincipal,
) -> IncidentCaseCreateResult:
    correlation = _correlate(request.events, request.policy, principal.tenant_id)
    try:
        cases, created_count, reused_count = await case_service.create_from_correlation(
            correlation,
            principal.tenant_id,
            principal.subject,
            request.note,
        )
    except CaseConflictError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return IncidentCaseCreateResult(
        correlation=correlation,
        created_case_count=created_count,
        reused_case_count=reused_count,
        cases=cases,
    )


@app.get("/cases/metrics", response_model=IncidentCaseMetrics)
def case_metrics(principal: ViewerPrincipal) -> IncidentCaseMetrics:
    return case_store.metrics(principal.tenant_id)


@app.get("/cases", response_model=list[IncidentCase])
def recent_cases(
    principal: ViewerPrincipal,
    limit: int = 20,
    status: IncidentCaseStatus | None = None,
) -> list[IncidentCase]:
    safe_limit = min(max(limit, 1), 100)
    return case_store.recent(safe_limit, principal.tenant_id, status)


@app.get("/cases/{case_id}", response_model=IncidentCase)
def case_detail(case_id: str, principal: ViewerPrincipal) -> IncidentCase:
    record = case_store.get(case_id, principal.tenant_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Case not found")
    return record


@app.patch("/cases/{case_id}", response_model=IncidentCase)
async def update_case(
    case_id: str,
    request: IncidentCaseUpdateRequest,
    principal: ResponderPrincipal,
) -> IncidentCase:
    try:
        return await case_service.transition(
            case_id,
            principal.tenant_id,
            principal.subject,
            request,
        )
    except CaseNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Case not found") from exc
    except (CaseConflictError, InvalidCaseTransitionError) as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get("/integrations/outbox/metrics", response_model=IntegrationOutboxMetrics)
def integration_outbox_metrics(principal: ViewerPrincipal) -> IntegrationOutboxMetrics:
    return integration_outbox_store.metrics(principal.tenant_id)


@app.get("/integrations/outbox", response_model=list[IntegrationOutboxRecord])
def recent_integration_events(
    principal: ViewerPrincipal,
    limit: int = 20,
    status: IntegrationDeliveryStatus | None = None,
    due_only: bool = False,
) -> list[IntegrationOutboxRecord]:
    safe_limit = min(max(limit, 1), 100)
    records = integration_outbox_store.recent(100, principal.tenant_id, status)
    if due_only:
        now = datetime.now(UTC)
        records = [
            record
            for record in records
            if record.status
            in {
                IntegrationDeliveryStatus.PENDING,
                IntegrationDeliveryStatus.RETRY_SCHEDULED,
            }
            and record.next_attempt_at is not None
            and record.next_attempt_at <= now
        ]
    return records[:safe_limit]


@app.post("/integrations/outbox/reconcile", response_model=IntegrationReconcileResult)
async def reconcile_integration_outbox(
    principal: AdminPrincipal,
) -> IntegrationReconcileResult:
    cases = case_store.recent(10000, principal.tenant_id)
    try:
        created, reused = await integration_outbox_service.reconcile_cases(cases)
    except (OutboxConflictError, RuntimeError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return IntegrationReconcileResult(
        scanned_case_count=len(cases),
        created_event_count=created,
        reused_event_count=reused,
    )


@app.get("/integrations/outbox/{event_id}", response_model=IntegrationOutboxRecord)
def integration_event_detail(
    event_id: str,
    principal: ViewerPrincipal,
) -> IntegrationOutboxRecord:
    record = integration_outbox_store.get(event_id, principal.tenant_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Integration event not found")
    return record


@app.post(
    "/integrations/outbox/{event_id}/attempt",
    response_model=IntegrationOutboxRecord,
)
async def record_integration_attempt(
    event_id: str,
    request: IntegrationDeliveryUpdateRequest,
    principal: ResponderPrincipal,
) -> IntegrationOutboxRecord:
    try:
        return await integration_outbox_service.record_attempt(
            event_id,
            principal.tenant_id,
            principal.subject,
            request,
        )
    except OutboxNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Integration event not found") from exc
    except (OutboxConflictError, OutboxNotDueError, OutboxTerminalStateError) as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get("/replay/public/datasets", response_model=list[PublicReplayDataset])
def public_replay_datasets(_: ViewerPrincipal) -> list[PublicReplayDataset]:
    return public_replay_service.datasets()


@app.post("/replay/public/run", response_model=PublicReplaySuiteResult)
def run_public_replay(principal: AnalystPrincipal) -> PublicReplaySuiteResult:
    if not public_replay_service.valid:
        raise HTTPException(status_code=503, detail="Public replay fixtures failed validation")
    return public_replay_service.run_all(principal.tenant_id)


@app.post("/replay/public/{dataset_id}", response_model=PublicReplayResult)
def run_public_replay_dataset(
    dataset_id: str,
    principal: AnalystPrincipal,
) -> PublicReplayResult:
    if not public_replay_service.valid:
        raise HTTPException(status_code=503, detail="Public replay fixtures failed validation")
    try:
        return public_replay_service.run_dataset(dataset_id, principal.tenant_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Public replay dataset not found") from exc


@app.get("/evaluation/detection-quality", response_model=DetectionQualityReport)
def detection_quality(principal: ViewerPrincipal) -> DetectionQualityReport:
    if not public_replay_service.valid or not sigma_engine.valid:
        raise HTTPException(status_code=503, detail="Detection quality inputs failed validation")
    return detection_quality_service.evaluate(principal.tenant_id)


@app.get("/evaluation/incident-quality", response_model=IncidentQualityReport)
def incident_quality(principal: ViewerPrincipal) -> IncidentQualityReport:
    if not public_replay_service.valid or not sigma_engine.valid:
        raise HTTPException(status_code=503, detail="Incident quality inputs failed validation")
    return incident_quality_service.evaluate(principal.tenant_id)


@app.get("/evaluation/detection-benchmark")
def detection_benchmark(
    _: ViewerPrincipal,
    split: Literal["development", "holdout"] = "holdout",
) -> dict:
    try:
        return get_detection_benchmark().evaluate(split)
    except BenchmarkUnavailable as exc:
        raise HTTPException(status_code=503, detail="Detection benchmark inputs failed validation") from exc


@app.post("/scenarios/evaluate", response_model=EventScenarioEvaluation)
def evaluate_event_scenarios(
    event: SecurityEvent,
    _: AnalystPrincipal,
) -> EventScenarioEvaluation:
    return evaluate_scenarios(event, SCENARIOS)


@app.post("/analysis", response_model=AnalysisResult)
async def analyze(
    event: SecurityEvent,
    request: Request,
    principal: AnalystPrincipal,
) -> AnalysisResult:
    try:
        analyzer = get_analyzer()
    except ValueError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    try:
        return await _analyze_event(event, analyzer, principal, request.state.request_id)
    except AnalysisCapacityExceeded as exc:
        raise HTTPException(
            status_code=429,
            detail="Analysis capacity is temporarily exhausted",
            headers={"Retry-After": "1"},
        ) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail="Analysis provider failed") from exc


@app.post("/analysis/batch", response_model=BatchAnalysisResult)
async def analyze_batch(
    batch_request: BatchAnalysisRequest,
    request: Request,
    principal: AnalystPrincipal,
) -> BatchAnalysisResult:
    try:
        analyzer = get_analyzer()
    except ValueError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    semaphore = asyncio.Semaphore(3)

    async def analyze_with_limit(event: SecurityEvent) -> AnalysisResult:
        async with semaphore:
            return await _analyze_event(event, analyzer, principal, request.state.request_id)

    try:
        results = await asyncio.gather(
            *(analyze_with_limit(event) for event in batch_request.events)
        )
    except AnalysisCapacityExceeded as exc:
        raise HTTPException(
            status_code=429,
            detail="Analysis capacity is temporarily exhausted",
            headers={"Retry-After": "1"},
        ) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail="Batch analysis provider failed") from exc
    return BatchAnalysisResult(
        analyzer=analyzer.name,
        requested=len(batch_request.events),
        completed=len(results),
        results=results,
    )


@app.post("/analysis/verified-session", response_model=AnalysisResult)
async def analyze_verified_session(
    signal: SignedSessionSignal,
    request: Request,
    principal: AnalystPrincipal,
    behavior_capture_id: Annotated[
        str | None, Query(pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
    ] = None,
) -> AnalysisResult:
    if zero_trust_operations is None:
        raise HTTPException(404, "Local verified-session analysis is disabled in production")
    # Verification errors are handled by existing signal/session handlers; never call the LLM.
    def collect_context():
        if behavior_capture_id is not None:
            return collect_session_execution_evidence(
                zero_trust_operations, behavior_context_service, signal, principal, behavior_capture_id
            )
        return collect_session_evidence(zero_trust_operations, signal, principal)

    context = collect_context()

    def verify_current_context():
        fresh = collect_context()
        before, after = context.for_event(signal.event), fresh.for_event(signal.event)
        before.pop("collected_at")
        after.pop("collected_at")
        if before != after:
            raise ValueError("verified session context changed during analysis")

    context = replace(context, verify_current=verify_current_context)
    try:
        analyzer = get_analyzer()
    except ValueError as exc:
        raise HTTPException(503, "Verified-session analysis provider is not configured") from exc
    if get_settings().openai_prompt_mode != "grounded" or not callable(
        getattr(analyzer, "analyze_with_evidence", None)
    ):
        raise HTTPException(
            503, "Configure grounded OpenAI or hybrid analysis for verified sessions"
        )

    class BoundSessionAnalyzer:
        name = analyzer.name

        async def analyze(self, event):
            result = await analyzer.analyze_with_evidence(event, context)
            # Source/key withdrawal, policy changes or revocation during a paid call
            # must not publish a result as if the original snapshot were still current.
            verify_current_context()
            return result

    try:
        return await _analyze_event(
            signal.event,
            BoundSessionAnalyzer(),
            principal,
            request.state.request_id,
            verification_context=context,
        )
    except AnalysisCapacityExceeded as exc:
        raise HTTPException(
            429, "Analysis capacity is temporarily exhausted", headers={"Retry-After": "1"}
        ) from exc
    except Exception as exc:
        # Provider failures and expiring snapshots do not yield a successful analysis.
        raise HTTPException(502, "Verified-session analysis could not be completed") from exc


async def _analyze_event(
    event: SecurityEvent,
    analyzer: Analyzer,
    principal: Principal,
    request_id: str,
    verification_context: VerifiedSessionContext | None = None,
) -> AnalysisResult:
    try:
        await asyncio.wait_for(
            analysis_capacity.acquire(),
            timeout=settings.analysis_queue_timeout_seconds,
        )
    except TimeoutError as exc:
        raise AnalysisCapacityExceeded from exc
    try:
        started = perf_counter()
        normalized = ocsf_normalizer.normalize(event)
        detection = sigma_engine.evaluate(normalized)
        assessment = await analyzer.analyze(event)
        if verification_context is not None:
            assessment = assessment.model_copy(update={"requires_human_review": True})
        snapshot = verification_context.for_event(event) if verification_context is not None else None
        safe_assessment = enforce_assessment_safety(assessment, event)
        decision = response_preview(safe_assessment, event)
        result = AnalysisResult(
            event_id=event.event_id,
            analyzer=analyzer.name,
            assessment=safe_assessment,
            policy_decision=decision,
            normalized_event=normalized,
            detection=detection,
            verification_context=snapshot,
            latency_ms=round((perf_counter() - started) * 1000, 2),
            tenant_id=principal.tenant_id,
            actor_id=principal.subject,
            request_id=request_id,
        )
        await audit_store.save(result)
        return result
    finally:
        analysis_capacity.release()


@app.post("/response/preview", response_model=PolicyDecision)
def preview(request: ResponsePreviewRequest, _: AnalystPrincipal) -> PolicyDecision:
    return response_preview(request.assessment, request.event)


@app.post("/evaluation/run", response_model=EvaluationSummary)
async def evaluate(request: EvaluationRequest, _: AdminPrincipal) -> EvaluationSummary:
    try:
        analyzer = build_analyzer(request.analyzer)
    except ValueError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return await run_evaluation(analyzer, request.runs_per_scenario, request.concurrency)


@app.get("/metrics", response_model=MetricsSummary)
def metrics(principal: ViewerPrincipal) -> MetricsSummary:
    return audit_store.metrics(principal.tenant_id)


@app.get("/internal/metrics", include_in_schema=False)
def prometheus_metrics(_: AdminPrincipal) -> Response:
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.get("/assurance/summary", response_model=AssuranceSummary)
def assurance_summary(_: ViewerPrincipal) -> AssuranceSummary:
    return assurance_registry.summary()


@app.get("/assurance/controls", response_model=list[ControlRecord])
def assurance_controls(
    _: AdminPrincipal,
    status: ControlStatus | None = None,
    domain: str | None = None,
) -> list[ControlRecord]:
    controls = assurance_registry.controls
    if status is not None:
        controls = [control for control in controls if control.status == status]
    if domain is not None:
        controls = [control for control in controls if control.domain == domain]
    return controls


@app.get("/assurance/controls/{control_id}", response_model=ControlRecord)
def assurance_control(control_id: str, _: AdminPrincipal) -> ControlRecord:
    try:
        return assurance_registry.get(control_id.upper())
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Control not found") from exc


@app.get("/results", response_model=list[AnalysisResult])
def recent_results(
    principal: ViewerPrincipal,
    limit: int = 20,
    review_status: ReviewStatus | None = None,
    risk_level: RiskLevel | None = None,
) -> list[AnalysisResult]:
    safe_limit = min(max(limit, 1), 100)
    records = audit_store.recent(100, principal.tenant_id)
    if review_status is not None:
        records = [record for record in records if record.review_status == review_status]
    if risk_level is not None:
        records = [record for record in records if record.assessment.risk_level == risk_level]
    return records[:safe_limit]


@app.patch("/results/{event_id}/review", response_model=AnalysisResult)
async def update_review(
    event_id: str,
    request: ReviewUpdateRequest,
    principal: ResponderPrincipal,
) -> AnalysisResult:
    record = audit_store.get(event_id, principal.tenant_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Result not found")
    if record.review_status == ReviewStatus.NOT_REQUIRED:
        raise HTTPException(status_code=409, detail="This result does not require human review")

    allowed_transitions = {
        ReviewStatus.PENDING: {
            ReviewStatus.IN_REVIEW,
            ReviewStatus.RESOLVED,
            ReviewStatus.DISMISSED,
        },
        ReviewStatus.IN_REVIEW: {
            ReviewStatus.IN_REVIEW,
            ReviewStatus.RESOLVED,
            ReviewStatus.DISMISSED,
        },
        ReviewStatus.RESOLVED: {ReviewStatus.IN_REVIEW},
        ReviewStatus.DISMISSED: {ReviewStatus.IN_REVIEW},
    }
    if request.status not in allowed_transitions.get(record.review_status, set()):
        raise HTTPException(
            status_code=409,
            detail=f"Cannot change review from {record.review_status.value} to {request.status.value}",
        )

    payload = record.model_dump()
    reviewer = request.reviewer if principal.auth_method == "disabled" else principal.subject
    if reviewer is None:
        raise HTTPException(status_code=422, detail="reviewer is required in local mode")
    payload.update(
        review_status=request.status,
        reviewer=reviewer,
        review_note=request.note,
        review_updated_at=datetime.now(UTC),
    )
    updated = AnalysisResult.model_validate(payload)
    await audit_store.save(updated)
    return updated


@app.get("/results/{event_id}", response_model=AnalysisResult)
def result(event_id: str, principal: ViewerPrincipal) -> AnalysisResult:
    record = audit_store.get(event_id, principal.tenant_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Result not found")
    return record


handler = Mangum(app, lifespan="off")
